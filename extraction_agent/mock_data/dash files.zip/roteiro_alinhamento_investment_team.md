# Roteiro de Alinhamento — Dashboard de Deal Terms
### Guia de conversas com o Investment Team

---

## Como usar este roteiro

**Sequência recomendada:**
1. **Conversa rápida com sócios/topo (15–20 min, em grupo ou individual)** — só os blocos A e F. Objetivo: patrocínio e permissão, não levantamento.
2. **Conversas com analistas/associates (30–40 min cada, individuais)** — roteiro completo. É aqui que mora o detalhe real.
3. **Retorno com sócios (20–30 min)** — apresentar síntese do que ouviu da base e usar o Bloco F para priorizar.

Prefira **conversas individuais** às em grupo para os Blocos B–E — em grupo, a pessoa mais sênior tende a dominar a resposta e você perde o detalhe tático de quem realmente sofre a dor no dia a dia.

---

## Bloco A — Contexto e enquadramento (abertura, todas as conversas)

Objetivo: alinhar expectativa antes de perguntar qualquer coisa.

- Explicar em 2 frases o que está sendo construído (dashboard + agente de consulta, dados revisados por Legal antes de virarem "oficiais").
- Deixar claro: **isso não substitui Legal para julgamento jurídico** — é para acesso rápido a fatos já documentados.
- "Essa conversa é para entender como vocês trabalham hoje, não para validar uma solução já pronta."

---

## Bloco B — Como funciona hoje (mapear o processo atual)

Objetivo: entender o fluxo real, não o idealizado.

1. Me conta a última vez que você precisou saber um termo específico de um deal — o que você fez, passo a passo?
2. Quando você precisa comparar termos entre deals (ex: "como está nosso liquidation preference médio"), como você faz isso hoje?
3. Quais perguntas você faz para o Legal com mais frequência? (Pedir exemplos concretos, não categorias abstratas.)
4. Dessas perguntas, quantas você diria que são "eu só preciso saber um fato que já está em algum documento" vs. "eu preciso de um julgamento/opinião jurídica"?
5. Quanto tempo, estimando, isso consome por semana/mês?

---

## Bloco C — Dores e fricções (o que já doeu de verdade)

Objetivo: casos concretos > opiniões gerais.

1. Já teve alguma situação em que a falta de acesso rápido a um termo custou tempo real ou quase custou uma decisão? Descreve.
2. Já aconteceu de descobrir tarde demais que um termo era diferente do que vocês esperavam (não-padrão)? O que aconteceu?
3. O que mais frustra em depender do Legal para essas perguntas — é o tempo de resposta, a disponibilidade, outra coisa?
4. Tem alguma pergunta que você já parou de fazer para o Legal porque sabia que ia demorar ou ser trabalhoso — mesmo sabendo que seria útil?

*(A última pergunta costuma revelar necessidade reprimida que não aparece nas outras.)*

---

## Bloco D — Quais termos importam de fato

Objetivo: validar/priorizar a lista do golden dataset com quem usa.

Mostrar a lista de categorias já mapeadas (Valuation/Price, Economics, Governance, Investor Protections, Liquidity, Mechanics, Risk Allocation, Compliance) e perguntar:

1. Dessas categorias, quais você consulta com mais frequência? Quais quase nunca olha?
2. Tem algum termo que não está nessa lista e que você sente falta?
3. Quando você olha um termo, o que mais importa: o valor em si, a comparação com nosso padrão, ou a comparação com outros deals do portfólio?
4. Existe alguma informação que você precisa **junto** com o termo para ele fazer sentido (ex: contexto do deal, quem mais estava na rodada)?

---

## Bloco E — Formato e uso no dia a dia

Objetivo: entender como isso se encaixa no fluxo real de trabalho, não só "o que", mas "quando" e "como".

1. Em que momentos do seu trabalho você precisaria disso — durante diligence de um deal novo? Preparação de board meeting? Reporting para LPs? Monitoramento contínuo do portfólio?
2. Você prefere abrir um dashboard e navegar, ou perguntar em linguagem natural (tipo chat) e receber a resposta direto?
3. Isso faria sentido no Slack, ou você prefere um link que abre numa aba separada?
4. Você imagina precisar disso reativamente (quando surge uma dúvida) ou proativamente (quer ser avisado quando algo relevante muda/vence)?
5. Que nível de confiança você precisaria ter no dado pra usar isso sem checar com Legal de novo? O que te daria essa confiança (ex: ver a citação da fonte, saber que foi revisado por Legal, etc.)?

---

## Bloco F — Priorização (usar principalmente com sócios/topo)

Objetivo: fechar com decisão acionável, não só levantamento aberto.

1. Se pudéssemos resolver só **uma** dessas fricções nos primeiros 3 meses, qual moveria mais o ponteiro?
2. Quais 3–5 deals reais fariam sentido como piloto?
3. Quem, além de mim, deveria estar envolvido na definição do que é "padrão Canary" para efeito de comparação?
4. O que faria vocês considerarem isso um sucesso claro em 3 meses? E o que faria vocês considerarem um fracasso?

---

## Depois das conversas — o que fazer com o material

- Consolidar respostas do Bloco D numa tabela: termo × quantas pessoas mencionaram × frequência de uso — isso vira a priorização real da lista de campos do golden dataset, em vez de uma lista definida só por Legal.
- As respostas do Bloco C (dores concretas) são o melhor material para o slide "O problema hoje" do pitch — trocar os exemplos genéricos por casos reais que a própria equipe descreveu.
- A pergunta de confiança (Bloco E, item 5) informa diretamente o que precisa aparecer visualmente no dashboard (ex: se "ver a citação" for a resposta mais comum, isso confirma que o painel de citação lateral já desenhado é a peça certa a priorizar).
