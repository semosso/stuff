# Protocolo de Debrief — Transição de GC (Canary)

Documento de trabalho. Estruturado para ser executado ao longo do período de aviso
da GC anterior, com apoio de Claude nas fases de preparação e processamento.

---

## Princípio de desenho

**Recurso escasso**: a atenção dela, não a sua. Estimativa realista de 10–15h úteis,
fragmentadas, com ela já em transição para a próxima posição. O protocolo é desenhado
para essa escassez.

**Filtro de admissão de pergunta** — toda pergunta candidata passa por dois testes:

1. *Recuperabilidade*: consigo responder isso em 6 meses, sozinho, com acesso aos
   documentos? Se sim → não é pergunta de debrief, é tarefa do agente de extração.
2. *Custo do erro*: o que me custa mais caro descobrir do jeito difícil? Ordena a fila.

O que sobra depois dos dois filtros é sempre uma de quatro coisas:

| Categoria | Por que só ela tem | Exemplo |
|---|---|---|
| Contrafactual | Documento registra a decisão, não a alternativa descartada | Por que Cayman e não Delaware no Fundo III |
| Mapa político | Nunca é escrito | Qual LP escala, qual GP decide o quê |
| Passivo latente | Deliberadamente não escrito | O que está mal resolvido e sendo empurrado |
| Prática vs. papel | Documento diz A, rotina faz B | "Na prática a gente nunca pediu isso ao LPAC" |

---

## Arquitetura em três fases

### Fase 0 — Extração documental (antes de qualquer sessão)

Objetivo: chegar na primeira sessão sabendo o suficiente para fazer perguntas de
segundo nível. Ninguém queima tempo de debrief explicando o que está no LPA.

Corpo documental a varrer, em ordem de prioridade:

- LPAs dos Fundos I a IV + emendas
- Side letters (todas) e subscription documents
- Documentos societários da gestora e dos GPs (incl. acordos de carry entre sócios)
- Regulamentos dos FIPs, atas de assembleia, atas de comitê de investimento
- Atos regulatórios: registro de gestora, códigos ANBIMA, registros Cayman, Form D
- Contratos com administrador, auditor, custodiante
- Últimos 8 relatórios trimestrais a LPs e últimas 2 cartas anuais
- Pareceres de outside counsel dos últimos 24 meses
- Documentos de deal (ver Fase 0-B, Track B)

Output desta fase, gerado com apoio de Claude:

1. **Tabela comparativa Fundo I → IV** por termo econômico e de governança
2. **Lista de anomalias**: termo que destoa do padrão do próprio Canary ou do mercado
3. **Lista de lacunas**: o que o corpo documental não explica — o insumo bruto do
   banco de perguntas
4. **Lista de obrigações vivas**: compromissos assumidos que ainda geram dever
   recorrente (reporting, consents, condições de fechamento não implementadas)

> A lista de lacunas é o que vira pauta. Não improvisar pauta.

### Fase 1 — Sessões

Três tracks paralelos, detalhados abaixo. Ordem de execução recomendada:
Track A (fundos) → Track C (pessoas) intercalado → Track B (deals) por último,
porque Track B é o que mais depende de triagem prévia e o que melhor tolera
formato assíncrono.

### Fase 2 — Verificação cruzada

Cada sessão transcrita é confrontada contra o corpo documental. O produto é um
**registro de divergências prática-vs-papel**, classificado por gravidade:

- *Benigna*: ela lembra errado, documento prevalece → corrigir nota
- *Costume*: rotina consolidada que o documento não proíbe → documentar como prática
- **Exposição**: documento exige algo que não vem sendo feito → ação imediata,
  provavelmente com outside counsel

Este registro é o entregável de maior valor do processo inteiro.

---

## TRACK A — Fundos e gestora

Cobertura exaustiva. Estimar 5 sessões de 60–90 min.

### A1. Estrutura e as decisões que a produziram

- Para cada fundo: por que essa estrutura (Cayman / Delaware / FIP), quem decidiu,
  qual era a alternativa e por que foi descartada
- Quais escolhas foram feitas por restrição de LP específico (e qual LP), quais por
  eficiência fiscal, quais por inércia da estrutura anterior
- Veículos paralelos, feeders, blockers: existe algum? Serve a quem? Ainda faz sentido?
- Onde está a fricção fiscal conhecida entre LP local e LP estrangeiro, e como foi
  resolvida (ou não)
- Alguma estrutura foi montada para uma situação que já não existe e nunca foi desfeita?

### A2. Economia do fundo

- Base de cálculo da management fee em cada fundo, e como funciona o step-down após o
  período de investimento — inclusive: quem calcula, e já houve divergência de cálculo?
- Waterfall: deal-by-deal ou whole-fund? Mudou entre gerações? Por quê?
- Catch-up, hurdle, e se há clawback de GP — e **como o clawback está garantido**
  (escrow, garantia pessoal, nada?)
- Recycling: existe, qual o limite, já foi usado?
- GP commitment: qual o percentual, como é financiado, há empréstimo aos sócios?
- Carry entre os sócios: como está dividido, qual o vesting, o que acontece com a
  parcela de um sócio que sai (good vs bad leaver) — **e isso já foi testado por
  alguma saída real?**
- Fees de portfolio (board fee, monitoring, transaction): existem, e são offsetados
  contra a management fee?

### A3. Governança e consentimentos

- Composição do LPAC de cada fundo, quem indica, com que frequência se reúne
- O que exige consentimento do LPAC vs. maioria de LPs vs. supermaioria — e onde a
  linha é ambígua na prática
- Key person: quem está nomeado, o que dispara, qual o período de cura, e o que
  aconteceria hoje se a cláusula fosse acionada
- No-fault divorce / remoção de GP: qual o quórum, algum LP já sinalizou desconforto?
- Período de investimento e extensões: prazos, quem consente, alguma extensão já foi
  pedida e como foi a conversa
- **Conflitos**: qual a política escrita e qual a prática real para (a) investimento
  cross-fund — Fundo III entrando em empresa do Fundo II, (b) alocação de follow-on
  entre fundos, (c) alocação de co-investimento entre LPs. Este é o bloco onde mais
  frequentemente há descolamento entre papel e prática.
- Política de valuation: quem marca, quem aprova, o auditor já contestou alguma marca?

### A4. LPs — o mapa que não está escrito

- Para cada LP relevante: quem é o contato real, o que ele pede fora do padrão,
  quão rápido escala, e há histórico de atrito?
- Quem já pediu excuse rights e sobre o quê
- Alguém já atrasou ou defaultou capital call? Como foi tratado?
- Quem tem transfer rights diferenciados; alguma solicitação de secundário de LP já veio?
- **Side letters e MFN**: quais são os tiers, quem tem direito a herdar o quê, e a
  eleição de MFN do Fundo IV foi de fato executada e documentada?
- O que foi prometido verbalmente em fundraising que não está em documento nenhum
- Quem sinalizou (formal ou informalmente) que pode não vir no Fundo V

### A5. DFIs — bloco próprio

IFC, BID e BNDES não são LPs comuns e a obrigação desce até a investida.

- Quais compromissos de E&S foram assumidos, e quem executa hoje
- Lista de exclusão: qual versão se aplica, e ela já bloqueou algum deal?
- Reps e obrigações anticorrupção: o que precisa constar nos documentos de investimento
  das portfolio companies por exigência de DFI — **isso está sendo feito de fato?**
- Direitos de auditoria e inspeção: já foram exercidos? Como foi?
- Reporting específico de cada um: periodicidade, formato, quem produz o dado
- Exigências de BNDES sobre destinação de recursos ou conteúdo local, se houver
- Condições precedentes de desembolso ainda pendentes

### A6. Regulatório e prestadores

- Situação de cada registro: CVM (gestora), ANBIMA, CIMA (Cayman), exemption invocada
  nos EUA (3(c)(1) vs 3(c)(7)), Form D
- Classificação FATCA/CRS de cada veículo e quem faz o reporting
- Programa de PLD/FT: quem é o responsável designado, quando foi o último teste
- Já houve ofício, questionamento ou processo de qualquer regulador? Como terminou?
- Administrador, auditor, custodiante: qualidade real de cada um, o que quebra,
  qual o contato que resolve
- **Pergunta de fecho de bloco**: existe alguma obrigação regulatória que você sabe
  que está sendo cumprida no limite, ou não sendo cumprida?

---

## TRACK B — Deals

Cobertura seletiva. Exaustividade aqui é impossível e desnecessária.

### B0. Triagem prévia (antes de qualquer pergunta)

Classificar o portfólio inteiro em três baldes, usando o agente de extração:

**Balde 1 — Debrief completo** (esperado: 8 a 15 empresas). Critérios, qualquer um basta:
- Exposição financeira no topo do portfólio
- Problema vivo: litígio, disputa societária, inadimplemento, crise de governança
- Canary tem assento no board (exposição pessoal de quem senta)
- Termo fora do padrão do próprio Canary
- Evento pendente: M&A em curso, rodada em negociação, down round provável
- Relação complicada com founder

**Balde 2 — Nota de uma linha** (o grosso do portfólio). Só: status, quem cobre,
alguma pendência? Formato assíncrono, ela responde em lista.

**Balde 3 — Sem debrief.** Write-offs consumados, posições irrelevantes, empresas
mortas. Só confirmar que não sobrou passivo.

### B1. O padrão — antes dos casos individuais

- Qual é a paper padrão do Canary por estágio, e o quanto ela é de fato usada
- Onde o Canary **nunca** cede em negociação, e onde cede fácil
- Pro rata: como está redigido, e o Canary tem exercido? Já perdeu pro rata por
  falha de acompanhamento?
- Information rights: o que os documentos exigem e o que de fato chega
- Política de assento em board vs. observador — e qual o critério
- Como o Canary tratou down rounds, pay-to-play e reestruturações até hoje
- Flip para Delaware: quantas investidas já fizeram, quem conduziu, e sobrou algum
  problema de cadeia societária ou tributário
- Secundários: o Canary já vendeu posição? Quais restrições de transferência mordem?

### B2. Por empresa do Balde 1

- Qual é o problema desta empresa que não está em nenhum documento
- Quem é o founder e como se comporta sob pressão
- Quem do Canary é o dono da relação
- O que está pendente de assinatura, arquivamento ou implementação
- Se tem assento: qual a exposição de quem senta, tem D&O, está vigente
- Existe algo em que o Canary tenha responsabilidade além do capital investido
- **O que você faria diferente aqui se pudesse voltar atrás**

### B3. Passivos difusos do portfólio

- Onde há erro conhecido de cap table
- Onde há falha de cessão de PI (fundador que não cedeu, prestador sem contrato)
- Onde há passivo trabalhista ou tributário material conhecido
- LGPD: alguma investida com incidente ou exposição relevante
- Plano de opções: quais investidas têm, quais estão mal implementados
- Alguma investida em setor regulado que gere obrigação reflexa para o fundo

---

## TRACK C — Pessoas, fornecedores e o funcionamento real

Curto, mas é o que determina seus primeiros 90 dias.

### C1. Internos

- Para cada GP: com quem se fecha o quê, quem quer detalhe e quem quer recomendação,
  quem muda de ideia, quem não pode ser surpreendido em reunião
- Quem no time te procura direto e sobre o quê
- Quem, fora do jurídico, produz insumo de que você depende (IR, financeiro, backoffice)
  e qual a confiabilidade de cada um
- O que o time de investimento acha que o jurídico atrasa
- Qual foi a briga interna recorrente do jurídico com o resto da casa

### C2. Externos

- Para cada escritório: qual tema, quem é o sócio que de fato atende, qualidade real,
  como é a cobrança, e você usaria de novo
- Quem é caro e vale, quem é caro e não vale
- Quem tem conflito com o Canary ou com alguma investida
- Há arranjo de fee, retainer ou desconto negociado que não está em contrato?
- Onde o Canary é dependente demais de um único fornecedor

### C3. As três perguntas de encerramento

Reservar para o fim, quando já há confiança estabelecida:

1. *O que você não vai ter tempo de resolver e está deixando pra mim?*
2. *O que te tirou o sono nesses anos?*
3. *Se você fosse eu, o que faria nos primeiros 30 dias — e o que não faria?*

---

## Mecânica das sessões

**Formato.** Sessões de 60–90 min, gravadas com autorização expressa dela.
Pauta enviada com 24h de antecedência — perguntas específicas, não temas genéricos.
Ela precisa poder consultar documento antes, não improvisar.

**Enquadramento.** Isso não é auditoria, e não pode soar como uma. Ela está saindo;
não tem obrigação de colaborar; e tem incentivo a não expor o que deu errado. O
enquadramento que funciona é continuidade, não avaliação: *"quero não desfazer sem
querer decisões que tinham razão de ser."* Perguntas de passivo latente vêm sempre
como pergunta de continuidade, nunca de responsabilidade.

**Assíncrono onde possível.** Balde 2 do Track B, lista de fornecedores e detalhes
factuais vão por escrito. E há um formato de alto retorno: pedir que ela grave áudio
sozinha percorrendo o Drive, comentando pasta por pasta. Extrai muito, custa pouco
tempo dela, e não exige agenda em comum.

**Fecho de cada sessão** — sempre as mesmas duas perguntas:
- *O que eu deveria ter perguntado e não perguntei?*
- *Quem mais sabe disso além de você?*

**Antes do último dia**, resolver o operacional que fica caro depois:
- Contato pessoal dela e um arranjo explícito de disponibilidade pós-saída
  (algo como duas ligações por mês nos primeiros 3 meses — pedir enquanto ela
  ainda está dentro, não depois)
- Apresentação nominal aos contatos de LP, DFI, administrador, auditor e escritórios
  — feita por ela, ainda no cargo
- Transferência de acessos, credenciais, pastas pessoais, e-mails arquivados
- Confirmação de onde está cada coisa que não está no Drive

---

## Pipeline de processamento com Claude

| Etapa | Ferramenta | Output |
|---|---|---|
| Varredura documental (Fase 0) | Claude Code — agente de extração, dicionário LP-side | Tabela comparativa I→IV, anomalias, obrigações vivas |
| Geração do banco de perguntas | Chat, sobre a lista de lacunas | Pauta por sessão, priorizada |
| Transcrição → fichas temáticas | Cowork | Ficha por tema, com citação do trecho da transcrição |
| Verificação cruzada | Cowork ou chat, ficha vs. documento | **Registro de divergências prática-vs-papel** |
| Iteração | Chat | Pauta da sessão seguinte, a partir das lacunas remanescentes |
| Consolidação final | Alimenta o repositório (item 1 do roadmap) | Base de conhecimento consultável |

Nota de sensibilidade: transcrição de debrief contém informação de LP, de investida e
avaliação sobre pessoas nomeadas. Vale rodar o processamento no setup local — mesma
lógica já adotada no agente de extração — e não em ferramenta com retenção aberta.

---

## Sinais de alerta durante as sessões

Vale marcar na transcrição e priorizar na verificação cruzada:

- Ela desvia de um tema duas vezes
- "Isso a gente sempre fez assim" sem base documental identificável
- "O [escritório X] disse que tudo bem" sem parecer escrito
- Divergência entre a versão dela e o documento em ponto econômico ou de consentimento
- Qualquer obrigação de DFI descrita como cumprida sem evidência de quem produz o insumo
- Qualquer coisa que ela descreva como "resolvido" mas sem documento que encerre
